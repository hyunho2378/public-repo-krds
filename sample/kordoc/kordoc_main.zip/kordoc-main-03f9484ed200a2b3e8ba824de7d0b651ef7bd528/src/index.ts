/**
 * kordoc — 모두 파싱해버리겠다
 *
 * HWP, HWPX, PDF → Markdown 변환 통합 라이브러리
 */

import { stripScriptTags } from "./script-tags.js"
import { toPlainMarkdown } from "./plain-markdown.js"
import { parsePageRange } from "./page-range.js"
import { toHtmlTables } from "./html-tables.js"
import { readFile } from "fs/promises"
import { detectFormat, detectOle2Format, detectZipFormat, isHwpxFile, isOldHwpFile, isPdfFile, isZipFile } from "./detect.js"
import { parseHwpxDocument } from "./hwpx/parser.js"
import { parseHwp5Document } from "./hwp5/parser.js"
import { parseHwp3Document } from "./hwp3/parser.js"
import { isComFallbackAvailable, extractTextViaCom, comResultToParseResult } from "./hwpx/com-fallback.js"
import { isDistributionSentinel } from "./hwp5/sentinel.js"
// pdfjs-dist는 optional peer dep (37MB) — PDF 안 쓰는 사용자를 위해 dynamic import
// import { parsePdfDocument } from "./pdf/parser.js"
import { parseXlsxDocument } from "./xlsx/parser.js"
import { parseXlsDocument } from "./xls/parser.js"
import { parseDocxDocument } from "./docx/parser.js"
import { parsePptxDocument } from "./pptx/parser.js"
import { parseHwpmlDocument } from "./hwpml/parser.js"
import type { ParseResult, ParseSuccess, ParseOptions, IRBlock } from "./types.js"
import { classifyError, sanitizeError, toArrayBuffer } from "./utils.js"
import { fillFormFields } from "./form/filler.js"
import type { FillResult } from "./form/filler.js"
import type { FillValue, FillInput } from "./form/match.js"
import { fillHwpx } from "./form/filler-hwpx.js"
import type { HwpxFillResult } from "./form/filler-hwpx.js"
import { blocksToMarkdown } from "./table/builder.js"
import { ocrEmbeddedImages } from "./ocr/embedded-image-ocr.js"
import { validateOcrOptions } from "./ocr/options.js"
import { inlineImagesIntoMarkdown } from "./image/transcode.js"
import { classifyTableTree } from "./table/analyze.js"
import { blocksToPages } from "./page-markdown.js"
import { markdownToHwpx } from "./hwpx/generator.js"

// ─── 메인 API ────────────────────────────────────────

/**
 * 파일 버퍼를 자동 감지하여 Markdown으로 변환
 *
 * @example
 * ```ts
 * import { parse } from "kordoc"
 * // 파일 경로로 파싱
 * const result = await parse("document.hwp")
 * // 또는 Buffer로 파싱
 * const result = await parse(buffer)
 * ```
 */
export async function parse(input: string | ArrayBuffer | Buffer, options?: ParseOptions): Promise<ParseResult> {
  let buffer: ArrayBuffer
  // 파일 경로 입력 시 filePath를 options에 자동 설정 (DRM COM fallback에 필요)
  const opts = typeof input === "string" && !options?.filePath
    ? { ...options, filePath: input }
    : options
  // htmlTables 는 GFM 표까지 HTML 로 옮기는 후처리라 tableFormat "gfm" 과 정반대 — 한쪽을 조용히 무시하지 않는다
  if (opts?.htmlTables && opts.tableFormat) {
    return { success: false, fileType: "unknown", error: "htmlTables 와 tableFormat 은 함께 쓸 수 없습니다" }
  }
  const ocrOptionError = validateOcrOptions(opts)
  if (ocrOptionError) return { success: false, fileType: "unknown", error: ocrOptionError }
  if (typeof input === "string") {
    try {
      const buf = await readFile(input)
      buffer = toArrayBuffer(buf)
    } catch (err) {
      const msg = err instanceof Error && "code" in err && (err as NodeJS.ErrnoException).code === "ENOENT"
        ? `파일을 찾을 수 없습니다: ${input}`
        : `파일 읽기 실패: ${input}`
      return { success: false, fileType: "unknown", error: msg, code: classifyError(err) }
    }
  } else if (Buffer.isBuffer(input)) {
    buffer = toArrayBuffer(input)
  } else {
    buffer = input
  }

  if (!buffer || buffer.byteLength === 0) {
    return { success: false, fileType: "unknown", error: "빈 버퍼이거나 유효하지 않은 입력입니다.", code: "EMPTY_INPUT" }
  }
  const format = detectFormat(buffer)

  const result = await dispatch(format, buffer, opts)
  // images:false: 포맷별 파서가 풀어 둔 이미지 바이트를 결과에서 뗀다 (PDF 는 파서가 PNG 인코딩부터 건너뜀)
  if (result.success && opts?.images === false) {
    delete result.images
    dropImageBytes(result.blocks)
  }
  // opt-in 표 분류(#76) — 구조 파싱 뒤 메타만 붙인다. 기본(미지정/false)은 산출 불변
  if (result.success && opts?.classifyTables) classifyTableTree(result.blocks)
  // 페이지별 마크다운(#68)은 파서가 채운 pageNumber 의 사영이라 여기서 한 번에
  // 붙인다. 포맷별 파서를 직접 부르는 호출자는 `blocksToPages(result.blocks)` 로
  // 같은 값을 얻는다.
  let out = result
  // 문서 쪽과 겹치지 않는 쪽 범위("abc"·"99") — 빈 결과를 조용히 성공으로 내던 것을 경고로 알린다
  if (result.success && opts?.pages && result.pageCount && parsePageRange(opts.pages, result.pageCount).size === 0) {
    out = { ...result, warnings: [...(result.warnings ?? []), { code: "PARTIAL_PARSE", message: `요청한 쪽 범위(${opts.pages})가 문서 쪽(1~${result.pageCount})과 겹치지 않습니다` }] }
  }
  if (out.success && !out.pages) {
    const pages = blocksToPages(out.blocks, bs => blocksToMarkdown(bs, { tableFormat: opts?.tableFormat }))
    if (pages) out = { ...out, pages }
  }
  // plain: 그림 자리 표시·링크 URL·밑줄/굵게 표기를 걷은 글 위주 Markdown (블록 IR 은 그대로)
  if (out.success && opts?.plain) {
    out = { ...out, markdown: toPlainMarkdown(out.markdown), ...(out.pages ? { pages: out.pages.map(p => ({ ...p, markdown: toPlainMarkdown(p.markdown) })) } : {}) }
  }
  // htmlTables: 모든 표를 태그마다 한 줄씩 들여쓴 HTML 로 (파이프 표 포함)
  if (out.success && opts?.htmlTables) {
    out = { ...out, markdown: toHtmlTables(out.markdown), ...(out.pages ? { pages: out.pages.map(p => ({ ...p, markdown: toHtmlTables(p.markdown) })) } : {}) }
  }
  return out
}

/** 블록 트리(자식·표 셀·캡션)에서 이미지 바이트(imageData)를 뗀다. 그림 자리 표시 블록은 남긴다 */
function dropImageBytes(blocks: IRBlock[] | undefined, depth = 0): void {
  if (!blocks || depth > 64) return
  for (const b of blocks) {
    if (b.imageData) delete b.imageData
    dropImageBytes(b.children, depth + 1)
    if (b.table) {
      for (const row of b.table.cells) for (const cell of row) dropImageBytes(cell.blocks, depth + 1)
      dropImageBytes(b.table.captionBlocks, depth + 1)
    }
  }
}

async function dispatch(
  format: ReturnType<typeof detectFormat>,
  buffer: ArrayBuffer,
  opts: ParseOptions | undefined,
): Promise<ParseResult> {
  switch (format) {
    case "hwpx": {
      // ZIP 기반 포맷 세분화: HWPX, XLSX, DOCX, PPTX 구분
      const zipFormat = await detectZipFormat(buffer)
      if (zipFormat === "xlsx") return parseXlsx(buffer, opts)
      if (zipFormat === "docx") return parseDocx(buffer, opts)
      if (zipFormat === "pptx") return parsePptx(buffer, opts)
      // unknown은 손상 ZIP·비표준 섹션 경로의 HWPX 복구를 위해 기존 파서로 전달
      return parseHwpx(buffer, opts)
    }
    case "hwp": {
      // OLE2 기반 포맷 세분화: HWP 5.x vs XLS (Excel 97-2003)
      const ole2Format = detectOle2Format(buffer)
      if (ole2Format === "xls") return parseXls(buffer, opts)
      return parseHwp(buffer, opts)
    }
    case "hwp3":
      return parseHwp3(buffer, opts)
    case "hwpml":
      return parseHwpml(buffer, opts)
    case "pdf":
      return parsePdf(buffer, opts)
    case "image":
      return parseImage(buffer, opts)
    default:
      return { success: false, fileType: "unknown", error: "지원하지 않는 파일 형식입니다.", code: "UNSUPPORTED_FORMAT" }
  }
}

/** HWP·HWPX 삽입 그림 속 글 OCR(#143, `ocr: true`·`"force"`·함수일 때만) — 그림 블록 뒤에 글을 넣었으면 마크다운을 블록에서 다시 만든다.
 *  `images` 는 그림 인라인(inlineImages, HWP 만)을 다시 걸 때만 넘긴다 */
async function withEmbeddedImageOcr(
  blocks: IRBlock[], markdown: string, warnings: ParseSuccess["warnings"], images: ParseSuccess["images"], options: ParseOptions | undefined,
): Promise<{ markdown: string; warnings: ParseSuccess["warnings"] }> {
  const list = [...(warnings ?? [])]
  if (!(await ocrEmbeddedImages(blocks, options, list))) return { markdown, warnings: list.length ? list : undefined }
  let md = blocksToMarkdown(blocks, { tableFormat: options?.tableFormat })
  if (options?.inlineImages && options.images !== false && images?.length) {
    try { md = inlineImagesIntoMarkdown(md, images, { compress: true }) } catch { /* 파서 경로와 같이 원본 참조로 둔다 */ }
  }
  return { markdown: md, warnings: list.length ? list : undefined }
}

/** 첨자 표기 끔 — 태그만 걷는다(ParseOptions.scriptTags) */
function scriptsOff(r: ParseSuccess, off: boolean): ParseSuccess {
  return off ? stripScriptTags(r) : r
}

/** 이미지(PNG/JPEG/WebP)를 OCR 로 Markdown 변환 — 텍스트층이 없으므로 OCR 상시 적용 */
export async function parseImage(buffer: ArrayBuffer, options?: ParseOptions): Promise<ParseResult> {
  try {
    const { parseImageDocument } = await import("./ocr/image-ocr.js")
    const { blocks, warnings, lines } = await parseImageDocument(buffer, options)
    // OCR 글은 첨자를 가르지 않는다(검출 박스로는 기준선을 믿을 수 없다) — scriptTags 와 무관하게 평문
    stripScriptTags({ blocks })
    return {
      success: true,
      fileType: "image",
      markdown: blocksToMarkdown(blocks, { tableFormat: options?.tableFormat }),
      blocks,
      warnings: warnings.length ? warnings : undefined,
      pageCount: 1,
      ...(options?.ocrLines ? { ocrLines: lines ? [lines] : [] } : {}),
    }
  } catch (err) {
    return { success: false, fileType: "image", error: sanitizeError(err), code: classifyError(err) }
  }
}

/** HWP 3.x (구버전 한컴 워드프로세서) 파일을 Markdown 으로 변환. */
export async function parseHwp3(buffer: ArrayBuffer, options?: ParseOptions): Promise<ParseResult> {
  try {
    const { markdown, blocks, metadata, outline, warnings, images } = parseHwp3Document(buffer, options)
    return { success: true, fileType: "hwp3", markdown, blocks, metadata, outline, warnings, images, pageCount: metadata?.pageCount }
  } catch (err) {
    // 에러 메시지 정제 — KordocError만 그대로, 내부 에러는 일반화 (MCP 노출 일관성)
    return { success: false, fileType: "hwp3", error: sanitizeError(err), code: classifyError(err) }
  }
}

// ─── 포맷별 API ──────────────────────────────────────

/** HWPX 파일을 Markdown으로 변환 */
export async function parseHwpx(buffer: ArrayBuffer, options?: ParseOptions): Promise<ParseResult> {
  try {
    const doc = await parseHwpxDocument(buffer, options)
    const { blocks, metadata, outline, images } = doc
    const { markdown, warnings } = await withEmbeddedImageOcr(blocks, doc.markdown, doc.warnings, undefined, options)
    return scriptsOff({ success: true, fileType: "hwpx", markdown, blocks, metadata, outline, warnings, images: images?.length ? images : undefined, pageCount: metadata?.pageCount }, options?.scriptTags === false)
  } catch (err) {
    return { success: false, fileType: "hwpx", error: sanitizeError(err), code: classifyError(err) }
  }
}

/** HWP 5.x 바이너리 파일을 Markdown으로 변환 */
export async function parseHwp(buffer: ArrayBuffer, options?: ParseOptions): Promise<ParseResult> {
  try {
    const { markdown, blocks, metadata, outline, warnings, images } = parseHwp5Document(Buffer.from(buffer), options)

    // 배포용 HWP 5.x 감지 — 본문이 "상위 버전의 배포용 문서입니다..." 플레이스홀더뿐이면
    // COM fallback으로 재시도 (Windows + 한컴오피스 환경에서만). 이슈 #25 대응.
    if (isDistributionSentinel(markdown) && isComFallbackAvailable() && options?.filePath) {
      try {
        const { pages, pageCount, warnings: comWarns } = extractTextViaCom(options.filePath)
        if (pages.some(p => p && p.trim().length > 0)) {
          const com = comResultToParseResult(pages, pageCount, comWarns)
          return {
            success: true,
            fileType: "hwp",
            markdown: com.markdown,
            blocks: com.blocks,
            metadata: com.metadata,
            warnings: com.warnings,
            pageCount,
          }
        }
      } catch {
        // COM 실패 시 기존 결과(경고 문자열 포함) 그대로 반환
      }
    }

    const ocred = await withEmbeddedImageOcr(blocks, markdown, warnings, images, options)
    return scriptsOff({ success: true, fileType: "hwp", markdown: ocred.markdown, blocks, metadata, outline, warnings: ocred.warnings, images: images?.length ? images : undefined, pageCount: metadata?.pageCount }, options?.scriptTags === false)
  } catch (err) {
    return { success: false, fileType: "hwp", error: sanitizeError(err), code: classifyError(err) }
  }
}

/** PDF 파일에서 텍스트를 추출하여 Markdown으로 변환 */
export async function parsePdf(buffer: ArrayBuffer, options?: ParseOptions): Promise<ParseResult> {
  let parsePdfDocument: typeof import("./pdf/parser.js").parsePdfDocument
  try {
    const mod = await import("./pdf/parser.js")
    parsePdfDocument = mod.parsePdfDocument
  } catch {
    return {
      success: false, fileType: "pdf",
      error: "PDF 파싱에 pdfjs-dist가 필요합니다. 설치: npm install pdfjs-dist",
      code: "MISSING_DEPENDENCY",
    }
  }
  try {
    const { markdown, blocks, metadata, outline, warnings, isImageBased, pageQuality, qualitySummary, images, pages, ocrLines } = await parsePdfDocument(buffer, options)
    // 첨자 표기 — PDF 는 기하 추정이라 기본 끔(scriptTags: true 로 켠다)
    return scriptsOff({ success: true, fileType: "pdf", markdown, blocks, metadata, outline, warnings, isImageBased, pageQuality, qualitySummary, images, pages, pageCount: metadata?.pageCount, ...(ocrLines ? { ocrLines } : {}) }, options?.scriptTags !== true)
  } catch (err) {
    const isImageBased = err instanceof Error && "isImageBased" in err ? true : undefined
    return { success: false, fileType: "pdf", error: sanitizeError(err), code: classifyError(err), isImageBased }
  }
}

/** XLSX 파일을 Markdown으로 변환 */
export async function parseXlsx(buffer: ArrayBuffer, options?: ParseOptions): Promise<ParseResult> {
  try {
    const { markdown, blocks, metadata, warnings } = await parseXlsxDocument(buffer, options)
    return { success: true, fileType: "xlsx", markdown, blocks, metadata, warnings, pageCount: metadata?.pageCount }
  } catch (err) {
    return { success: false, fileType: "xlsx", error: sanitizeError(err), code: classifyError(err) }
  }
}

/** XLS (Excel 97-2003) 파일을 Markdown으로 변환 */
export async function parseXls(buffer: ArrayBuffer, options?: ParseOptions): Promise<ParseResult> {
  try {
    const { markdown, blocks, metadata, warnings } = await parseXlsDocument(buffer, options)
    return { success: true, fileType: "xls", markdown, blocks, metadata, warnings, pageCount: metadata?.pageCount }
  } catch (err) {
    return { success: false, fileType: "xls", error: sanitizeError(err), code: classifyError(err) }
  }
}

/** DOCX 파일을 Markdown으로 변환 */
export async function parseDocx(buffer: ArrayBuffer, options?: ParseOptions): Promise<ParseResult> {
  try {
    const { markdown, blocks, metadata, outline, warnings, images } = await parseDocxDocument(buffer, options)
    return scriptsOff({ success: true, fileType: "docx", markdown, blocks, metadata, outline, warnings, images: images?.length ? images : undefined, pageCount: metadata?.pageCount }, options?.scriptTags === false)
  } catch (err) {
    return { success: false, fileType: "docx", error: sanitizeError(err), code: classifyError(err) }
  }
}

/** PPTX (PowerPoint) 파일을 Markdown으로 변환 — 슬라이드 1장 = 1쪽 */
export async function parsePptx(buffer: ArrayBuffer, options?: ParseOptions): Promise<ParseResult> {
  try {
    const { markdown, blocks, metadata, outline, warnings, images } = await parsePptxDocument(buffer, options)
    return scriptsOff({ success: true, fileType: "pptx", markdown, blocks, metadata, outline, warnings, images: images?.length ? images : undefined, pageCount: metadata?.pageCount }, options?.scriptTags === false)
  } catch (err) {
    return { success: false, fileType: "pptx", error: sanitizeError(err), code: classifyError(err) }
  }
}

/** HWPML (XML 기반 한컴 문서) 파일을 Markdown으로 변환 */
export async function parseHwpml(buffer: ArrayBuffer, options?: ParseOptions): Promise<ParseResult> {
  try {
    const { markdown, blocks, metadata, outline, warnings } = parseHwpmlDocument(buffer, options)
    return { success: true, fileType: "hwpml", markdown, blocks, metadata, outline, warnings, pageCount: metadata?.pageCount }
  } catch (err) {
    return { success: false, fileType: "hwpml", error: sanitizeError(err), code: classifyError(err) }
  }
}

// ─── 서식 채우기 API ────────────────────────────────

/**
 * 서식 채우기 출력 포맷
 * - "markdown": 마크다운 텍스트
 * - "hwpx": 새로 생성한 HWPX (스타일 초기화)
 * - "hwpx-preserve": 원본 HWPX ZIP 직접 수정 (스타일 100% 보존, HWPX 입력만 가능)
 */
export type FillOutputFormat = "markdown" | "hwpx" | "hwpx-preserve"

/** 서식 채우기 결과 */
export interface FillFormOutput {
  /** 채워진 문서 (markdown: string, hwpx/hwpx-preserve: ArrayBuffer) */
  output: string | ArrayBuffer
  /** 출력 포맷 */
  format: FillOutputFormat
  /** 채우기 상세 — filled 필드 목록 + unmatched 라벨 */
  fill: { filled: import("./types.js").FormField[]; unmatched: string[] }
}

/**
 * 서식 문서를 파싱하여 필드를 채우고, 원하는 포맷으로 출력.
 *
 * - "hwpx-preserve": HWPX 입력 → 원본 ZIP XML 직접 수정 (테두리/폰트/병합 등 100% 보존)
 * - "hwpx": 아무 포맷 → IRBlock → Markdown → HWPX 생성 (스타일 초기화됨)
 * - "markdown": 아무 포맷 → IRBlock → Markdown
 *
 * @example
 * ```ts
 * // HWPX 원본 스타일 보존 채우기
 * const result = await fillForm("신청서.hwpx", { "성명": "홍길동" }, "hwpx-preserve")
 * writeFileSync("결과.hwpx", Buffer.from(result.output as ArrayBuffer))
 *
 * // 아무 포맷 → 마크다운 채우기
 * const result = await fillForm("신청서.hwp", { "성명": "홍길동" })
 * console.log(result.output)  // 채워진 마크다운
 * ```
 */
export async function fillForm(
  input: string | ArrayBuffer | Buffer,
  values: Record<string, FillInput>,
  outputFormat: FillOutputFormat = "markdown",
): Promise<FillFormOutput> {
  // 입력 버퍼 준비
  let buffer: ArrayBuffer
  if (typeof input === "string") {
    const buf = await readFile(input)
    buffer = toArrayBuffer(buf)
  } else if (Buffer.isBuffer(input)) {
    buffer = toArrayBuffer(input)
  } else {
    buffer = input
  }

  // hwpx-preserve: 원본 HWPX ZIP 직접 수정 (스타일 보존)
  if (outputFormat === "hwpx-preserve") {
    const format = detectFormat(buffer)
    // detectFormat은 ZIP이면 "hwpx" 반환 (XLSX/DOCX 포함), 세분화 필요
    if (format === "hwpx") {
      const zipFormat = await detectZipFormat(buffer)
      if (zipFormat !== "hwpx") {
        throw new Error(`hwpx-preserve 포맷은 HWPX 입력만 지원합니다 (감지된 포맷: ${zipFormat})`)
      }
    } else {
      throw new Error(`hwpx-preserve 포맷은 HWPX 입력만 지원합니다 (감지된 포맷: ${format})`)
    }
    const hwpxResult = await fillHwpx(buffer, values)
    return {
      output: hwpxResult.buffer,
      format: "hwpx-preserve",
      fill: { filled: hwpxResult.filled, unmatched: hwpxResult.unmatched },
    }
  }

  // 일반 경로: parse → IRBlock → fill → output
  // 양식 칸은 원본 표 구조 그대로 — 보이지 않는 틀 표를 풀면 라벨·값 칸 짝이 흩어진다. 끝 빈 열(입력란)도 CLI fill 처럼 남긴다:
  // 자르면 "대표자 | (빈칸)" 의 값 칸이 없어져 못 채우고, 하위 라벨("성 명") 옆 빈 칸이 안 보여 라벨 칸을 덮어썼다 (#47·#145)
  const parsed = await parse(buffer, { layoutTables: "keep", keepTrailingEmptyCols: true })
  if (!parsed.success) {
    throw new Error(`서식 파싱 실패: ${parsed.error}`)
  }

  const fill = fillFormFields(parsed.blocks, values)
  const markdown = blocksToMarkdown(fill.blocks)

  if (outputFormat === "hwpx") {
    const hwpxBuffer = await markdownToHwpx(markdown)
    return { output: hwpxBuffer, format: "hwpx", fill }
  }

  return { output: markdown, format: "markdown", fill }
}

// ─── 게임체인저 API ─────────────────────────────────

export { compare, diffBlocks } from "./diff/compare.js"
export { extractFormFields, isLabelCell, extractFormSchema, inferFieldType } from "./form/recognize.js"
export type { FormFieldType, FormFieldSchema, FormSchemaResult } from "./form/recognize.js"
export { fillFormFields } from "./form/filler.js"
export { ValueCursor, formatFillValue, fillWithUniqueGuard } from "./form/match.js"
export type { FillValue, FillInput } from "./form/match.js"
export type { FillResult } from "./form/filler.js"
export { fillHwpx } from "./form/filler-hwpx.js"
export type { HwpxFillResult } from "./form/filler-hwpx.js"
export { extractClickHereFields } from "./form/click-here.js"
export type { ClickHereField } from "./form/click-here.js"
export { BUILTIN_TEMPLATES, resolveBuiltinTemplate, readBuiltinTemplate, readBuiltinTemplateSample } from "./form/templates.js"
export type { BuiltinTemplate } from "./form/templates.js"
export { placeSealHwpx } from "./form/seal.js"
export type { SealOp, SealPlacement, PlaceSealResult } from "./form/seal.js"
export { markdownToHwpx } from "./hwpx/generator.js"
// 기관팩 — 기관 문서(HWPX) 몇 건으로 만든 서식 묶음(.kpack). markdownToHwpx(md, { template: packTemplate(pack, "report") })
export { buildAgencyPack, loadAgencyPack, packTemplate, resolvePackKind, packRoleWarnings, packSummary } from "./hwpx/agency-pack.js"
export type { AgencyPack, PackManifest, PackKindInfo, PackSample } from "./hwpx/agency-pack.js"
export type { HwpxTheme, MarkdownToHwpxOptions } from "./hwpx/generator.js"
export type { PageOptions } from "./hwpx/gen-page.js"
export type {
  FormatProfile, TableProfile, CellProfile, BorderFillDef, BorderDef, CharPrDef,
} from "./hwpx/generator.js"
export { hwpxToProfile } from "./hwpx/extract-profile.js"
export { normalizeGongmunPreset, PRESET_ALIAS, incompatibleGongmunWarnings } from "./hwpx/gongmun.js"
export { agencyNames, agencyStyle, AGENCY_COMMON_NAME } from "./hwpx/agency.js"
export type { AgencyStyle, AgencyReportStyle, AgencyPressStyle, AgencyFont } from "./hwpx/agency-styles.js"
export { isKnownFont, unknownFontWarnings } from "./hwpx/font-catalog.js"
export { lintGongmunText, gongmunLintWarnings } from "./hwpx/gongmun-lint.js"
export type { GongmunLintFinding } from "./hwpx/gongmun-lint.js"
export { lintMuncheText, muncheLintWarnings, usesGaejosikMunche } from "./hwpx/munche-lint.js"
export type { MuncheLintFinding, MuncheLineKind } from "./hwpx/munche-lint.js"
export { lintSlopText, slopLintWarnings } from "./hwpx/slop-lint.js"
export { lintLogicText, logicLintWarnings, usesLogicStructure } from "./hwpx/logic-lint.js"
export { gongmunGate, formatGateFinding } from "./hwpx/gongmun-gate.js"
export { lintBudgetText } from "./hwpx/budget-lint.js"
export { runLintSuite, type LintSuiteOptions, type LintSuiteResult } from "./hwpx/lint-suite.js"
export { lintBlocks, type LintBlock, type BlockFinding, type LintBlocksResult } from "./hwpx/lint-blocks.js"
export { placeTotalRow, type TotalRowPosition } from "./hwpx/gen-table.js"
export type { GongmunGateResult, GongmunGateFinding, GongmunGateAxis } from "./hwpx/gongmun-gate.js"
export {
  charWidthEm1000, measureTextWidth, simulateWrap, simulateWrapKeepWord, fitRatioForFewerLines,
  SPACE_EM_FIXED, SPACE_EM_FONT,
} from "./hwpx/text-metrics.js"
export type { MeasureOptions, WrapResult, WrapMode } from "./hwpx/text-metrics.js"
export type {
  GongmunOptions,
  GongmunPreset,
  GongmunPresetInput,
  GongmunNumbering,
  GongmunFont,
} from "./hwpx/gongmun.js"
export { patchHwpx } from "./roundtrip/patcher.js"
export { patchHwp } from "./roundtrip/hwp5-patch.js"
export type { PatchResult, PatchSkip, PatchOptions } from "./types.js"
export { validateHwpx } from "./validate.js"
export type { ValidateResult, ValidateIssue } from "./validate.js"
export { redactText, redactMarkdown, DEFAULT_REDACT_RULES } from "./redact.js"
export type { RedactRule, RedactHit, RedactTextResult, RedactOptions } from "./redact.js"
export { blocksToChunks } from "./chunks.js"
export type { DocChunk, ChunkOptions } from "./chunks.js"

// ─── 에디터 통합 API (v3.1) ─────────────────────────

export { HwpxSession, openHwpxDocument, patchHwpxBlocks } from "./roundtrip/session.js"
export type {
  BlockEdit, BlockCapability, BlockCapabilityInfo, CellCapability, BlockSourceRef,
} from "./roundtrip/session.js"
// 소스맵 저수준 API — 블록↔원본 바인딩을 직접 다루는 고급 사용자용
export { scanSectionXml, buildParagraphSplices, buildRangeSplices, applySplices } from "./roundtrip/source-map.js"
export type {
  SectionScan, ScanParagraph, ScanCell, ScanTable, ScanParaKind, SpliceEdit, TRange,
} from "./roundtrip/source-map.js"
export { renderHtml, markdownToPdf, blocksToPdf } from "./print/renderer.js"
export type { PrintPreset, PrintOptions, PageMargin } from "./print/renderer.js"
export { renderHwpxToSvg, renderDocument, renderDocumentToScene, extractRenderedRegions, renderSceneToHtml, renderHwp5Pages } from "./render/index.js"
// 표 분류·시각 추출 (#76)
export { classifyTable, collectTableBlocks } from "./table/classifier.js"
export type { ClassifyContext } from "./table/classifier.js"
export { classifyTableTree, chooseTableRepresentation } from "./table/analyze.js"
export type { TableRepresentation } from "./table/analyze.js"
export { hasStructuredCellContent, flattenLayoutTables } from "./table/builder.js"
export { extractTables } from "./table/visual.js"
export type { ExtractTableVisualOptions, ExtractedTable, ExtractedTableCrop, TableVisualPolicy } from "./table/visual.js"
export type {
  RenderSvgOptions, RenderSvgResult, RenderScene, ScenePage, RenderRegion, PageBBox, RenderObjectType, RenderSourceFormat,
  RenderFormat, RenderDocumentOptions, RenderDocumentResult, RenderAsset, SceneRenderOptions, SceneRenderResult,
  ExtractRegionOptions, RegionAsset,
} from "./render/index.js"

// ─── Re-exports ──────────────────────────────────────

export { detectFormat, detectOle2Format, detectZipFormat, isHwpxFile, isOldHwpFile, isPdfFile, isZipFile } from "./detect.js"
export type {
  ParseResult, ParseSuccess, ParseFailure, FileType,
  PageMarkdown, PageQuality, DocumentQualitySummary,
  IRBlock, IRBlockType, IRTable, IRCell, CellContext,
  BoundingBox, InlineStyle, ImageData, ExtractedImage,
  DocumentMetadata, ParseOptions, ErrorCode,
  ParseWarning, WarningCode, OutlineItem,
  DiffResult, BlockDiff, CellDiff, DiffChangeType,
  FormField, FormResult,
  OcrProvider, OcrModelFile, OcrPageLines, OcrLine, WatchOptions,
} from "./types.js"
export { blocksToMarkdown } from "./table/builder.js"
export type { MarkdownOptions } from "./table/builder.js"
export { blocksToPages } from "./page-markdown.js"
export { VERSION } from "./utils.js"
